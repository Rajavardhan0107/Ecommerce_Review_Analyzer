# Ecommerce_Review_Analyzer
Develop a system to analyze e-commerce reviews and identify user sentiment and product quality insights. Can highlight product strengths/weaknesses such as battery life, performance, shipping issues.
